
import Navbar from './Navbar'

const Home = () => {
  return (
    <div>
        <Navbar/>
    </div>
  )
}

export default Home